




#include <iostream>
#include <cstdio>
using namespace std;

//	13. getche()
		int main () {
			char kar;
			
			printf("Masukan Sebuah Karakter = ");
			kar = getche();
			printf("\nAnda Memasukan %c", kar);
		}
//	NOTE : getche bisa jalan di C++ Turbo atau MinGW 
//		   dengan library <conio.h>
















