// contoh 1

#include <iostream>
using namespace std;

int main() {
	int a, b;
	a = 10;
	b = 4;
	a = b;
	b = 7;
	
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	
	return 0;
}
