// contoh 2

#include <iostream>
using namespace std;

int main() {
	int a, b = 3;
	a = b;
	a += 2;
	cout << a;
	
	return 0;
}
