// contoh 4

#include <iostream>
using namespace std;


int main () {
	int a, b;
	string c;
	
	a = 2;
	b = 7;
	c = (a > b) ? "true" : "false";
	
	cout << c;
	
	return 0;
}
