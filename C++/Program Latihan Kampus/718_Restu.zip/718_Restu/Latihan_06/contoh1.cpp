// Pertemuan 6
// contoh 1

#include <iostream>
using namespace std;

int main () {
	int bil = 1;
	
	while (bil <= 10) {
		cout << bil << endl;
		++bil;
	}
	
	return 0;
}
