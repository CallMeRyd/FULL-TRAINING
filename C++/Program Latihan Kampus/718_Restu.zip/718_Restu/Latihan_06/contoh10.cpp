// Pertemuan 6
// contoh 10

#include <iostream>
using namespace std;

int main () {
	int bil;
	
	for (bil = 60; bil >= 10; bil++) {
		printf("%d", bil);
	} 
	
	return 0;
}
