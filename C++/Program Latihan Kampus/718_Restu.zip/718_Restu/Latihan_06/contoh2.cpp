// Pertemuan 6
// contoh 2

#include <iostream>
using namespace std;

int main () {
	int bil = 2;
	
	while (bil <= 10) {
		cout << bil << endl;
		bil += 2;
	}
	
	return 0;
}
