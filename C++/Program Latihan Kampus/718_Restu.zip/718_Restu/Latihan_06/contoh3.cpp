// Pertemuan 6
// contoh 3

#include <iostream>
using namespace std;

int main () {
	int bil = 2;
	
	do {
		cout << bil << endl;
		bil += 2;
	} while (bil <= 10);
	
	return 0;
}
