// Pertemuan 6
// contoh 4

#include <iostream>
using namespace std;

int main () {
	int a;
	
	for (a = 1; a <= 10; ++a) {
		cout << a;
	}
	
	return 0;
}
