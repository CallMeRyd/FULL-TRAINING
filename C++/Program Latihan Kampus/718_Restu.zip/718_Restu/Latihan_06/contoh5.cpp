// Pertemuan 6
// contoh 5

#include <iostream>
using namespace std;

int main () {
	int a;
	
	for (a = 10; a >= 1; --a) {
		cout << a;
	}
	
	return 0;
}
