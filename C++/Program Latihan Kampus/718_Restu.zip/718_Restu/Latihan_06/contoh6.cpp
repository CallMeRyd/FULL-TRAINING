// Pertemuan 6
// contoh 6

#include <iostream>
using namespace std;

int main () {
	int a;
	
	for (a = 1; a <= 10; a += 2) {
		cout << a;
	}
	
	return 0;
}
