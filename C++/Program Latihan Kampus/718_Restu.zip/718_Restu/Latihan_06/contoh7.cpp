// Pertemuan 6
// contoh 7

#include <iostream>
using namespace std;

int main () {
	int a = 2, b = 1, c = 2, d = 1, e;
	
	for (e = 1; 17 > e; e++) {
		printf("\nwarna ke-%d", e);
	}
	
	return 0;
}
