// Pertemuan 6
// contoh 8

#include <iostream>
using namespace std;

int main () {
	int i = 0;
	
	for (i = 0; i < 20; i++) {
		cout << i + ((i + 1) + 4 ) << "\n";
	}
	
	return 0;
}
