// Contoh 1
// Addition

#include <iostream>
using namespace std;

int addition (int a, int b) {
	int r;
	r = a + b;
	return r;
}

int main () {
	int z;
	z = addition (5, 3);
	cout << "The Result is " << z;
	
	return 0;
}
