// Contoh 2
// Function

#include <iostream>
using namespace std;

void dummyFunction () {
	cout << "I am a function!";
}

int main () {
	dummyFunction();
	
	return 0;
}
