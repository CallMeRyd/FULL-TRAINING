// Contoh 3
// Variabel Local

#include <iostream>
using namespace std;

int perjumlahan () {
	// Local Variabel declaration :
	int a, b, c;
	
	// Actual initialization
	a = 10;
	b = 20;
	c = a + b;
	
	cout << c;
	
	return 0;
}
